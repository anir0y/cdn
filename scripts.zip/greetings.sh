#!/bin/bash

read -p "Enter Your Name: " name

echo "Hello $name, Nice to meet you!"