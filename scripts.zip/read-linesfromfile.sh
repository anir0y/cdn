#!/bin/bash

echo "pass the file name "
echo "read-linesformfile.sh filename"

cat $1 | while read line ; do
	echo $line
done