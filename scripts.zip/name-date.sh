#!/bin/bash

date="$(date)"
user="$(whoami)"

read -p "Enter Your Name: " name

echo "Hello $name, You're currently logged in as $user and time is $date"