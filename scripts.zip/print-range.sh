#!/bin/bash

for n in {11..20}; do
	echo "Number is $n"
done