#!/bin/bash

print_name() {
	echo "$name"
}

read -p "Enter Name: " name

echo "Your name is $(print_name)"