#!/bin/bash

read -p "Enter a number[0-9]: "  num
 
if [[ $num == 0 ]]; then
	echo "Number is zero"
elif [[ $num > 5 ]]; then
	echo "Number is greater then five!"
elif [[ $num < 5 && !=0 ]]; then
	echo "Try again!"
fi